package resources;

import networking.Simulation_Interface;
import networking.Track_Model_Interface;
import networking.Train_Controller_Interface;
import networking.Train_Model_Interface;
import resources.Train_Model_Catalogue;

import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class Simulation implements Simulation_Interface {

    public static boolean connected_Module_1; // Track Model
    public static boolean connected_Module_2; // Train Controller
    public static boolean serving = false;

    public static String module_0_IP = "73.79.47.187"; // Zach IP
    public static String module_1_IP = "71.173.141.165"; // Tony IP
    public static String module_2_IP = "73.154.129.166"; // Lee IP
    public static String module_3_IP = "69.80.136.151"; // Adnan IP
    public static String module_5_IP = "67.171.70.64"; // Meyers IP

    public static int module_0_Port = 1000; // Zach
    public static int module_1_Port = 1100; // Tony
    public static int module_2_Port = 1200; // Lee
    public static int module_3_Port = 1300; // Adnan Port
    public static int module_5_Port = 1500; // Meyers Port
    public static Train_Controller_Interface tc_Interface; // Train Controller Interface
    public static Track_Model_Interface tm_Interface; // Track Model Interface
    //    public static CTC_Interface ctc_Interface; // Track Model Interface
//    public static Track_Controller_SW_Interface tcs_Interface;
//    public static Track_Controller_HW_Interface tch_Interface;
    //public static Train_Model_Catalogue server_Object;
    public static int multiplier = 1;
    static double time = 0;

    public static void main(String[] args) throws RemoteException, InterruptedException {
        //start_Server();
        while (connected_Module_2 != true) {
            try {
                connect_To_Modules();
            } catch (Exception e) {

            }

        }

        while (true) {
            send_Time();
            time += .5;
            Thread.sleep(500 / multiplier);

        }

    }
    public static void send_Time() {
        tc_Interface.update_Time(time);

    }


//    public static void start_Server() throws RemoteException {
//        try {
//            System.setProperty("sun.rmi.transport.tcp.responseTimeout", "5000");
//            System.setProperty("java.rmi.server.hostname", "73.154.133.183");
//            // Instantiating the implementation class
//            server_Object = new Train_Model_Catalogue();
////
////            // (here we are exporting the remote object to the stub)
//            Train_Model_Interface stub = (Train_Model_Interface) UnicastRemoteObject.exportObject(server_Object, 2000);
//
//            // Binding the remote object (stub) in the registry
//            Registry registry = LocateRegistry.createRegistry(2000);
//            registry.rebind("Train_Model_Interface", stub);
//            //registry.rebind("Train_Model_Interface", stub2);
//
//            System.err.println("Server ready");
//            serving = true;
//
//        } catch (Exception e) {
//            System.err.println("Server exception: " + e.toString());
//            e.printStackTrace();
//        }
//    }

    public static void connect_To_Modules() {
//        if (!connected_Module_1) {
//            try {
//                Registry registry = LocateRegistry.getRegistry(module_1_IP, module_1_Port);
//                System.out.println("1");
//                tm_Interface = (Track_Model_Interface) registry.lookup("CTC_Interface");
//                System.out.println("2");
//                tm_Interface.appendToHolder("titties");
//                System.out.println("3");
//                connected_Module_1 = true;
//            } catch (Exception e) {
//                System.err.println("Client exception: " + e.toString());
//                e.printStackTrace();
//            }
//        }
        if (!connected_Module_2) {
            try {
                Registry registry = LocateRegistry.getRegistry(module_5_IP, module_5_Port);
                tc_Interface = (Train_Controller_Interface) registry.lookup("Train_Controller_Interface");
                connected_Module_2 = true;
            } catch (Exception e) {
                System.err.println("Client exception: " + e.toString());
                e.printStackTrace();
            }
        }
    }
}